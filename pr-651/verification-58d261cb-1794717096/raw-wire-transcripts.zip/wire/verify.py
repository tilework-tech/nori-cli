#!/usr/bin/env python3
"""Independent PR651 black-box protocol checks; stdlib only, scratch artifacts only."""
import argparse, base64, json, os, queue, select, shlex, socket, struct, subprocess, threading, time, traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
WORK=ROOT/'work'
WORK.mkdir(exist_ok=True)
if not (WORK/'.git').exists(): subprocess.run(['git','init',str(WORK)],check=True,capture_output=True)
BIN=REPO/'.local/pr651-target/debug/nori'
MOCK=BIN.with_name('mock_acp_agent')
SCRIPTS=Path('/home/sprite/org/workspace/.codex/skills/tui-puppeteering-with-tmux')
RESULTS=[]
def note(name, **kw):
    result={'check':name,**kw}; RESULTS.append(result); print(json.dumps(result), flush=True)
    (ROOT/'results.json').write_text(json.dumps(RESULTS,indent=2))
def cfg(name,on=True):
    home=ROOT/name; home.mkdir(exist_ok=True)
    (home/'config.toml').write_text(f'agent="mock-model"\napproval_policy="on-request"\n[features]\nmulti_session={str(on).lower()}\n[projects."{WORK}"]\ntrust_level="trusted"\n')
    return home
def env(home,extra=None):
    return dict(os.environ,NORI_HOME=str(home),CODEX_HOME=str(home),MOCK_ACP_AGENT_BIN=str(MOCK),NORI_NO_ANALYTICS='1',**(extra or {}))
class Client:
    def init_common(self,name):
        self.q=queue.Queue(); self.events=[]; self.all=[]; self.seq=100; self.file=(ROOT/(name+'.jsonl')).open('w'); self.closed=False; self.rawfile=(ROOT/(name+'.received.raw.jsonl')).open('w')
    def log(self,direction,value):
        self.file.write(json.dumps({'time':time.time(),'direction':direction,'message':value})+'\n'); self.file.flush()
    def dispatch(self,v,raw=None):
        if raw is not None: self.rawfile.write(raw.rstrip('\n')+'\n'); self.rawfile.flush()
        self.log('recv',v); self.all.append(v)
        if v.get('method')=='_nori/session/event': self.events.append(v['params'])
        self.q.put(v)
    def recv(self,timeout=15):
        value=self.q.get(timeout=timeout)
        if isinstance(value,Exception): raise value
        return value
    def request(self,method,params=None,timeout=15):
        self.seq+=1; rid=self.seq
        self.send({'jsonrpc':'2.0','id':rid,'method':method,'params':params or {}})
        end=time.monotonic()+timeout
        while time.monotonic()<end:
            v=self.recv(end-time.monotonic())
            if v.get('id')==rid: return v
        raise TimeoutError(method)
    def ok(self,method,params=None,timeout=15):
        v=self.request(method,params,timeout); assert 'result' in v,v; return v['result']
    def wait(self,pred,timeout=15):
        end=time.monotonic()+timeout
        while time.monotonic()<end:
            v=self.recv(end-time.monotonic())
            if pred(v): return v
        raise TimeoutError('predicate')
class Stdio(Client):
    def __init__(self,name,on=True,extra=None):
        self.init_common(name)
        self.err=(ROOT/(name+'.stderr')).open('w')
        self.p=subprocess.Popen([str(BIN),'--agent','mock-model','exec','--acp'],cwd=WORK,env=env(cfg(name+'-home',on),extra),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.err)
        threading.Thread(target=self.reader,daemon=True).start()
    def reader(self):
        try:
            for line in self.p.stdout: self.dispatch(json.loads(line),line.decode())
        except Exception as e: self.q.put(e)
    def send(self,v):
        self.log('send',v); self.p.stdin.write((json.dumps(v)+'\n').encode()); self.p.stdin.flush()
    def close(self):
        self.p.stdin.close(); self.p.wait(15); self.closed=True; self.file.close(); self.err.close()
class WS(Client):
    def __init__(self,name,port,path='/sessions'):
        self.init_common(name); self.sock=socket.create_connection(('127.0.0.1',port),10); self.sock.settimeout(15)
        key=base64.b64encode(os.urandom(16)).decode()
        self.sock.sendall(f'GET {path} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n'.encode())
        raw=b''
        while b'\r\n\r\n' not in raw: raw+=self.sock.recv(1)
        self.log('handshake',raw.decode()); assert raw.startswith(b'HTTP/1.1 101'),raw
        self.sock.settimeout(None); self.thread=threading.Thread(target=self.reader,daemon=True); self.thread.start()
    def exact(self,n):
        out=b''
        while len(out)<n:
            if self.closed: raise EOFError('local reader stopped')
            if not select.select([self.sock],[],[],.1)[0]: continue
            chunk=self.sock.recv(n-len(out))
            if not chunk: raise EOFError('socket EOF')
            out+=chunk
        return out
    def frame(self,op,data):
        mask=os.urandom(4); n=len(data)
        prefix=bytes([128|op,128|n]) if n<126 else bytes([128|op,128|126])+struct.pack('!H',n) if n<65536 else bytes([128|op,128|127])+struct.pack('!Q',n)
        self.sock.sendall(prefix+mask+bytes(b^mask[i%4] for i,b in enumerate(data)))
    def reader(self):
        try:
            while True:
                a,b=self.exact(2); op=a&15; n=b&127
                if n==126: n=struct.unpack('!H',self.exact(2))[0]
                if n==127: n=struct.unpack('!Q',self.exact(8))[0]
                mask=self.exact(4) if b&128 else None; data=self.exact(n)
                if mask: data=bytes(x^mask[i%4] for i,x in enumerate(data))
                if op==1: self.dispatch(json.loads(data),data.decode())
                elif op==9: self.frame(10,data)
                elif op==8: self.log('close',data.hex()); raise EOFError('WebSocket close frame')
                elif op==0: raise AssertionError('Unexpected fragmented WS frame')
        except Exception as e:
            self.closed_time=time.time()
            self.log('reader_terminated', {'error_type':type(e).__name__, 'error':str(e), 'locally_stopped':self.closed})
            self.closed=True; self.q.put(e)
    def send(self,v): self.log('send',v); self.frame(1,json.dumps(v).encode())
    def close(self,rst=False):
        self.closed=True; self.thread.join(timeout=2)
        assert not self.thread.is_alive(), 'reader did not release socket'
        if rst:
            self.log('fault',{'type':'TCP_RST','SO_LINGER':[1,0]}); self.sock.setsockopt(socket.SOL_SOCKET,socket.SO_LINGER,struct.pack('ii',1,0))
        self.sock.close()

def initialize(c,stdio=False):
    return c.ok('initialize',{'protocolVersion':1,'clientCapabilities':{}} if stdio else {})
def new(c): return c.ok('session/new',{'cwd':str(WORK),'mcpServers':[]})['sessionId']
def prompt(c,sid,text): return c.ok('_nori/session/prompt',{'session_id':sid,'prompt':[{'type':'text','text':text}]})
def listed(c): return c.ok('_nori/session/list')
def wait_ready(c,ids,timeout=20):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        data=listed(c); rows={r['session_id']:r for r in data['sessions']}
        if all(rows[i]['status']=='ready' for i in ids): return data
        time.sleep(.05)
    raise AssertionError(data)
def envelope_check(events):
    by={}
    for e in events:
        assert isinstance(e['agent'],str) and e['agent']; assert isinstance(e['conversation_id'],str); assert isinstance(e['seq'],int)
        by.setdefault(e['conversation_id'],[]).append(e['seq'])
    for sid,seq in by.items(): assert seq==list(range(seq[0],seq[-1]+1)),(sid,seq)
    return {sid:len(seq) for sid,seq in by.items()}
def run_exec(on):
    c=Stdio('exec-on' if on else 'exec-off',on)
    try:
        init=initialize(c,True); a=new(c)
        if not on:
            res=c.ok('session/prompt',{'sessionId':a,'prompt':[{'type':'text','text':'flag-off baseline'}]})
            assert res['stopReason']=='end_turn'; assert not c.events
            note('exec flag off',status='pass',session=a,result=res,notification_methods=[v['method'] for v in c.all if 'method' in v]); return
        assert init['agentCapabilities']['_meta']['nori/multiSession']['version']==1
        b=new(c); d=new(c); ids=[a,b,d]
        assert len(set(ids))==3
        c.ok('_nori/session/subscribe',{'session_id':'*'})
        for n,sid in enumerate(ids): prompt(c,sid,f'wire-route-{n}')
        wait_ready(c,ids)
        for n,sid in enumerate(ids):
            assert any(e['conversation_id']==sid and f'wire-route-{n}' in json.dumps(e) for e in c.events)
        counts=envelope_check(c.events)
        prompt(c,b,'mock:request-permission:echo wire-permission')
        end=time.monotonic()+15
        while time.monotonic()<end:
            row=next(r for r in listed(c)['sessions'] if r['session_id']==b)
            if row['pending_requests']: break
            time.sleep(.05)
        rid=row['pending_requests'][0]
        params={'session_id':b,'request_id':rid,'response':{'outcome':{'outcome':'selected','optionId':'allow'}}}
        assert c.ok('_nori/session/respond',params)['answered']
        duplicate=c.request('_nori/session/respond',params); assert 'error' in duplicate
        wait_ready(c,ids)
        assert any('RequestResolved' in json.dumps(e) or 'request_resolved' in json.dumps(e) for e in c.events)
        cursor=listed(c)['replay_cursors']; start=len(c.events)
        c.ok('_nori/session/subscribe',{'session_id':a,'cursors':{a:cursor[a]}})
        prompt(c,b,'unsubscribed-session-marker'); prompt(c,a,'subscribed-session-marker'); wait_ready(c,ids)
        assert c.events[start:] and all(e['conversation_id']==a for e in c.events[start:])
        note('exec flag on',status='pass',sessions=ids,initial_envelopes=counts,duplicate_answer=duplicate['error'],single_session_filter=True)
    finally: c.close()
class Host:
    def __init__(self,name,on=True,extra=None):
        self.name='pr651-wire-'+name; home=cfg(name+'-host-home',on)
        s=socket.socket();s.bind(('127.0.0.1',0));self.port=s.getsockname()[1];s.close()
        command=['env']+[f'{k}={v}' for k,v in env(home,extra).items() if k in ['NORI_HOME','CODEX_HOME','MOCK_ACP_AGENT_BIN','NORI_NO_ANALYTICS'] or k.startswith('MOCK_AGENT_')]+[str(BIN),'--agent','mock-model','--skip-trust-directory','--remote',str(self.port)]
        launcher=ROOT/(name+'-launch.sh');launcher.write_text('#!/bin/bash\ncd '+shlex.quote(str(WORK))+'\nexec '+shlex.join(command)+'\n');launcher.chmod(0o700)
        subprocess.run([str(SCRIPTS/'tui-start'),self.name,str(launcher)],check=True,capture_output=True)
        end=time.monotonic()+25
        while time.monotonic()<end:
            try:
                sock=socket.create_connection(('127.0.0.1',self.port),.2);sock.close();subprocess.run([str(SCRIPTS/'tui-assert'),self.name,'Mock Default Model','20'],check=True,capture_output=True);return
            except OSError: time.sleep(.1)
        raise TimeoutError('host listener')
    def capture(self):
        out=subprocess.run([str(SCRIPTS/'tui-capture'),self.name],capture_output=True,text=True)
        (ROOT/(self.name+'.terminal.txt')).write_text(out.stdout)
    def close(self):
        self.capture(); subprocess.run([str(SCRIPTS/'tui-send'),self.name,'/quit'],capture_output=True);time.sleep(.55)
        subprocess.run([str(SCRIPTS/'tui-send'),self.name,'--keys','Enter'],capture_output=True);time.sleep(.8)
        subprocess.run([str(SCRIPTS/'tui-stop'),self.name],capture_output=True)
def connect_host(host,name):
    c=WS(name,host.port);initialize(c)
    end=time.monotonic()+20
    while time.monotonic()<end:
        data=listed(c)
        if data['sessions'] and data['sessions'][0]['status']=='ready': return c,data['sessions'][0]['session_id']
        time.sleep(.1)
    raise AssertionError(data)
def run_reconnect():
    host=Host('reconnect')
    try:
        c,sid=connect_host(host,'ws-before-rst');c.ok('_nori/session/subscribe',{'session_id':'*'})
        # Send without waiting for admission; cut while actual downstream output is arriving.
        c.send({'jsonrpc':'2.0','id':900,'method':'_nori/session/prompt','params':{'session_id':sid,'prompt':[{'type':'text','text':'hard-drop-turn mock:stream-until-cancel'}]}})
        c.wait(lambda v:v.get('method')=='_nori/session/event' and 'Streaming...' in json.dumps(v))
        c.close(rst=True);time.sleep(.3)
        before=list(c.events);cursors={e['conversation_id']:e['seq'] for e in before}
        after=WS('ws-after-rst',host.port);initialize(after)
        after.ok('_nori/session/subscribe',{'session_id':'*','cursors':cursors})
        after.wait(lambda v:v.get('method')=='_nori/session/event' and v['params']['seq']>cursors[sid]+10 and 'Streaming...' in json.dumps(v))
        subprocess.run([str(SCRIPTS/'tui-send'),host.name,'--keys','Escape'],check=True,capture_output=True)
        data=wait_ready(after,[sid])
        latest=data['replay_cursors'][sid]
        end=time.monotonic()+10
        while (not after.events or after.events[-1]['seq']<latest) and time.monotonic()<end: time.sleep(.01)
        reconstructed=before+list(after.events)
        # A fresh replay is an independent server-side oracle; no typed ACP round-trip.
        start=len(after.events);after.ok('_nori/session/subscribe',{'session_id':sid})
        end=time.monotonic()+10
        while len(after.events)-start<latest and time.monotonic()<end: time.sleep(.01)
        reference=after.events[start:];assert reconstructed==reference,(len(reconstructed),len(reference))
        counts=envelope_check(reconstructed)
        (ROOT/'reconnect-reconstructed.json').write_text(json.dumps(reconstructed,indent=2));(ROOT/'reconnect-reference.json').write_text(json.dumps(reference,indent=2))
        note('WS hard TCP reset replay',status='pass',cut_cursor=cursors,total_envelopes=counts,raw_payload_equality=True)
        # Replacement is expected, including cross-endpoint legacy controller.
        newer=WS('ws-second-client',host.port);initialize(newer)
        end=time.monotonic()+3
        while not after.closed and time.monotonic()<end:time.sleep(.01)
        assert after.closed
        legacy=WS('ws-third-legacy',host.port,'/acp');initialize(legacy,True)
        end=time.monotonic()+3
        while not newer.closed and time.monotonic()<end:time.sleep(.01)
        assert newer.closed
        note('multiple clients',status='pass',contract='last connection wins across /sessions and /acp')
        legacy.close()
    finally: host.close()
def run_expiry():
    host=Host('expiry',extra={'MOCK_AGENT_RESPONSE':'y'*5000,'MOCK_AGENT_RESPONSE_CHUNK_CHARS':'1'})
    try:
        c,sid=connect_host(host,'ws-expiry');old=listed(c)['replay_cursors'][sid]
        prompt(c,sid,'overflow-production-journal');data=wait_ready(c,[sid]);row=next(r for r in data['sessions'] if r['session_id']==sid)
        assert row['latest_seq']>4096 and row['first_available_seq']>old+1,row
        expired=c.request('_nori/session/subscribe',{'session_id':sid,'cursors':{sid:old}})
        assert expired['error']['code']==-32003 and 'expired' in expired['error']['message'],expired
        start=len(c.events)
        boundary=row['first_available_seq']-1
        c.ok('_nori/session/subscribe',{'session_id':sid,'cursors':{sid:boundary}})
        end=time.monotonic()+15
        while len(c.events)-start<4096 and time.monotonic()<end: time.sleep(.01)
        retained=c.events[start:]; assert len(retained)==4096,len(retained)
        assert retained[0]['seq']==row['first_available_seq'] and retained[-1]['seq']==row['latest_seq']
        envelope_check(retained)
        c.ok('_nori/session/subscribe',{'session_id':sid,'cursors':{sid:row['latest_seq']}})
        note('production 4096 expiry',status='pass',row=row,old_cursor=old,error=expired['error'],valid_boundary_cursor=boundary,retained_envelopes=len(retained));c.close()
    finally:host.close()
def run_ws_off():
    host=Host('off',False)
    try:
        sock=socket.create_connection(('127.0.0.1',host.port));sock.sendall(b'GET /sessions HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n');response=sock.recv(2048);sock.close();assert response.startswith(b'HTTP/1.1 404'),response
        c=WS('ws-off-legacy',host.port,'/acp');init=initialize(c,True)
        end=time.monotonic()+20
        while time.monotonic()<end:
            rows=c.ok('session/list')['sessions']
            if rows:break
            time.sleep(.1)
        sid=rows[0]['sessionId'];r=c.ok('session/prompt',{'sessionId':sid,'prompt':[{'type':'text','text':'legacy baseline'}]});assert r['stopReason']=='end_turn';assert not c.events
        note('WS flag off',status='pass',managed_endpoint=404,legacy_prompt=r);c.close()
    finally:host.close()
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('checks',nargs='*',default=['exec','reconnect','expiry','off']);args=parser.parse_args()
    funcs={'exec':lambda:(run_exec(False),run_exec(True)),'reconnect':run_reconnect,'expiry':run_expiry,'off':run_ws_off}
    for name in args.checks:
        try:funcs[name]()
        except Exception as e:note(name,status='FAIL',error=repr(e),traceback=traceback.format_exc())
