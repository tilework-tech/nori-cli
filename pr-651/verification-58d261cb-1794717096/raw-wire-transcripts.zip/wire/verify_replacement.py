#!/usr/bin/env python3
"""Focused controller replacement evidence; preserves earlier wire artifacts."""
import hashlib,json,time
from pathlib import Path
from verify import Host,WS,initialize,listed,connect_host
root=Path(__file__).resolve().parent
proofs=['reconnect-reconstructed.json','reconnect-reference.json']
before={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in proofs}
host=Host('replacement-evidence');clients=[];checks=[]
try:
    first,sid=connect_host(host,'replacement-1-managed');clients.append(first)
    first.ok('_nori/session/subscribe',{'session_id':sid})
    first.log('assertion',{'state':'initialized subscribed and usable','session_id':sid})
    second_started=time.time()
    second=WS('replacement-2-managed',host.port);clients.append(second);initialize(second)
    end=time.monotonic()+5
    while not first.closed and time.monotonic()<end:time.sleep(.01)
    assert first.closed,'first client remained connected'
    assert listed(second)['selected_session_id']==sid
    second.log('assertion',{'predecessor_closed':True,'predecessor_closed_time':first.closed_time,'latest_usable':True})
    checks.append({'predecessor':'replacement-1-managed','successor':'replacement-2-managed','closed':True,'seconds_from_connect':first.closed_time-second_started,'successor_usable':True})
    third_started=time.time()
    third=WS('replacement-3-legacy',host.port,'/acp');clients.append(third);initialize(third,True)
    end=time.monotonic()+5
    while not second.closed and time.monotonic()<end:time.sleep(.01)
    assert second.closed,'second client remained connected'
    sessions=third.ok('session/list')['sessions'];assert any(s['sessionId']==sid for s in sessions),sessions
    response=third.ok('session/prompt',{'sessionId':sid,'prompt':[{'type':'text','text':'replacement-third-client-still-usable'}]})
    assert response['stopReason']=='end_turn',response
    assert not third.closed,'third client unexpectedly closed'
    third.log('assertion',{'predecessor_closed':True,'predecessor_closed_time':second.closed_time,'latest_usable':True,'prompt_response':response})
    checks.append({'predecessor':'replacement-2-managed','successor':'replacement-3-legacy','closed':True,'seconds_from_connect':second.closed_time-third_started,'successor_usable':True,'prompt_response':response})
finally:
    for c in clients:c.close()
    host.close()
after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in proofs}
assert before==after
result={'status':'pass','checks':checks,'reconnect_proof_hashes_unchanged':after}
(root/'replacement-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
