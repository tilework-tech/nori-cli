import os, pathlib, subprocess, time, json
ROOT=pathlib.Path('/home/sprite/org/workspace/cli')
OUT=ROOT/'.local/pr651-verification/root'
TUI=pathlib.Path('/home/sprite/org/workspace/.codex/skills/tui-puppeteering-with-tmux')
CAP=pathlib.Path('/home/sprite/org/workspace/.codex/skills/tui-capture-with-ghostty-web/scripts/capture-session')
BIN=ROOT/'.local/pr651-target/debug'
class Driver:
    def __init__(self,name,port,cap=4,flag=True):
        self.name=name; self.port=port
        self.home=OUT/name; self.home.mkdir(parents=True,exist_ok=True)
        (self.home/'config.toml').write_text(f'agent = "mock-model"\n[features]\nmulti_session = {str(flag).lower()}\n[tui]\nmax_sessions = {cap}\n')
        launcher=self.home/'launch.sh'
        launcher.write_text(f'''#!/bin/bash
cd {self.home}
export NORI_HOME={self.home} CODEX_HOME={self.home}
export MOCK_ACP_AGENT_BIN={BIN}/mock_acp_agent
export MOCK_AGENT_RESPONSE_MOCK_MODEL='alpha agent answer'
export MOCK_AGENT_RESPONSE_MOCK_MODEL_ALT='beta agent answer'
export MOCK_AGENT_PERMISSION_DELAY_MS=800
export NORI_NO_ANALYTICS=1 NORI_MOCK_INSTRUCTION_FILES=1
export TERM=xterm-256color COLORTERM=truecolor
unset NO_COLOR
exec {BIN}/nori --agent mock-model --skip-trust-directory --remote {port}
''')
        self.run('tui-start',name,f'bash {launcher}')
        self.wait('›',20)
        self.wait('ACP URLs:',20)
    def run(self,script,*args):
        p=subprocess.run([str(TUI/script),*map(str,args)],capture_output=True,text=True)
        if p.returncode: raise RuntimeError(f'{script}: {p.stdout}\n{p.stderr}')
        return p.stdout
    def screen(self): return self.run('tui-capture',self.name)
    def wait(self,text,timeout=12): return self.run('tui-assert',self.name,text,timeout)
    def key(self,key):
        self.run('tui-send',self.name,'--keys',key)
        time.sleep(.25)
    def submit(self,text):
        self.run('tui-send',self.name,text)
        time.sleep(.55)
        self.key('Enter')
    def capture(self,label,expect):
        self.wait(expect)
        self.save(label)
        dest=OUT/f'{self.name}-{label}'
        subprocess.run([str(CAP),self.name,str(dest),'--cols','120','--rows','40','--expect',expect,'--require-color'],check=True)
        return str(dest/'screen.png')
    def save(self,label):
        (OUT/f'{self.name}-{label}.txt').write_text(self.screen())
    def stop(self): self.run('tui-stop',self.name)
