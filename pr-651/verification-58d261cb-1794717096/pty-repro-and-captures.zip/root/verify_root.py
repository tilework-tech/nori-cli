import sys, json, time, subprocess, pathlib, traceback
from drive import *
sys.path.insert(0,str(ROOT/'.local/pr651-verification/wire'))
from verify import WS,initialize,listed,wait_ready,prompt
results=[]
def result(name,**kw):
    row={'check':name,**kw};results.append(row);print(json.dumps(row),flush=True);(OUT/'results.json').write_text(json.dumps(results,indent=2))
def snapshot_processes(label):
    v=subprocess.check_output(['ps','-eo','pid,ppid,pgid,sid,stat,args'],text=True)
    (OUT/f'processes-{label}.txt').write_text(v)
    return v

def run():
    d=Driver('pr651-root-main',39551,cap=3)
    c=WS('root-targeting',d.port);initialize(c)
    try:
        data=listed(c)
        end=time.monotonic()+20
        while not data['selected_session_id'] and time.monotonic()<end:
            time.sleep(.1);data=listed(c)
        a=data['selected_session_id'];wait_ready(c,[a]);c.ok('_nori/session/subscribe',{'session_id':'*'})
        prompt(c,a,'ALPHA history before crash');wait_ready(c,[a]);d.wait('alpha agent answer')
        d.submit('/new');d.wait('2 ready');b=listed(c)['selected_session_id']
        prompt(c,b,'BETA second session');wait_ready(c,[b]);d.wait('BETA second session')
        d.submit('/new');d.wait('3 ready');z=listed(c)['selected_session_id']
        prompt(c,z,'GAMMA newest session');wait_ready(c,[z]);d.wait('GAMMA newest session')
        assert len({a,b,z})==3
        d.key('M-,');d.wait('BETA second session');d.key('M-,');d.wait('ALPHA history before crash')
        assert listed(c)['selected_session_id']==a
        c.ok('_nori/session/prompt',{'prompt':[{'type':'text','text':'DEFAULT goes to ALPHA not newest'}]});wait_ready(c,[a]);d.wait('DEFAULT goes to ALPHA')
        prompt(c,z,'EXPLICIT goes to GAMMA while ALPHA is visible');wait_ready(c,[z])
        assert any(e['conversation_id']==a and 'DEFAULT goes to ALPHA' in json.dumps(e) for e in c.events)
        assert any(e['conversation_id']==z and 'EXPLICIT goes to GAMMA' in json.dumps(e) for e in c.events)
        assert 'EXPLICIT goes to GAMMA' not in d.screen()
        d.capture('three-session-default','DEFAULT goes to ALPHA')
        result('3 session managed targeting',status='pass',sessions=[a,b,z],selected=a,newest=z)
        c.close()
        legacy=WS('root-legacy-pinned',d.port,'/acp');initialize(legacy,True)
        l=legacy.ok('session/list');assert l['sessions'][0]['sessionId']==a,l
        d.key('M-.');d.wait('BETA second session')
        legacy.ok('session/prompt',{'sessionId':a,'prompt':[{'type':'text','text':'PINNED ALPHA after screen switched to BETA'}]})
        assert 'PINNED ALPHA' not in d.screen()
        d.key('M-,');d.wait('PINNED ALPHA');d.key('M-.');d.wait('BETA second session')
        legacy.close()
        fresh=WS('root-legacy-fresh',d.port,'/acp');initialize(fresh,True)
        assert fresh.ok('session/list')['sessions'][0]['sessionId']==b
        fresh.close()
        result('legacy chosen session remains pinned, new connection follows screen',status='pass',pinned=a,new_default=b)
        c=WS('root-crash-resume',d.port);initialize(c)
        before=listed(c);(OUT/'before-crash-list.json').write_text(json.dumps(before,indent=2))
        prompt(c,b,'mock:exit-during-prompt');d.wait('1 failed',15)
        failed=listed(c);(OUT/'failed-list.json').write_text(json.dumps(failed,indent=2))
        d.key('M-s');d.wait('Sessions 3');d.capture('failed-before-resume','failed')
        d.key('C-r');d.wait('3 ready',20)
        time.sleep(.4)
        resumed=listed(c);(OUT/'after-resume-list.json').write_text(json.dumps(resumed,indent=2))
        replacement=[r for r in resumed['sessions'] if r.get('resumed_from')==b]
        assert replacement,resumed
        new_id=replacement[0]['session_id']
        d.wait('BETA second session');d.capture('resumed-history','BETA second session')
        prompt(c,new_id,'RESUMED session accepts a followup');wait_ready(c,[new_id]);d.wait('RESUMED session accepts')
        result('Ctrl+R crash resume identity and history',status='fail' if new_id!=b else 'pass',old_id=b,new_id=new_id,resumed_from=replacement[0].get('resumed_from'),history_retained=True,usable=True)
        # Managed permission response must dismiss the visible prompt.
        prompt(c,new_id,'mock:request-permission:echo ROOT-MANAGED-ANSWER')
        d.wait('ROOT-MANAGED-ANSWER')
        end=time.monotonic()+15
        while time.monotonic()<end:
            row=next(r for r in listed(c)['sessions'] if r['session_id']==new_id)
            if row['pending_requests']:break
            time.sleep(.1)
        rid=row['pending_requests'][0]
        answer=c.ok('_nori/session/respond',{'session_id':new_id,'request_id':rid,'response':{'outcome':{'outcome':'selected','optionId':'allow'}}})
        wait_ready(c,[new_id]);time.sleep(.4)
        screen=d.screen();d.save('managed-answer-cleared')
        assert 'Yes, proceed' not in screen and 'esc to cancel' not in screen,screen
        prompt(c,new_id,'AFTER remote approval cleared');wait_ready(c,[new_id]);d.wait('AFTER remote approval')
        result('managed answer clears visible approval',status='pass',answer=answer)
        snapshot_processes('before-quit-main')
        d.submit('/quit');time.sleep(1)
        snapshot_processes('after-quit-main')
    finally:
        c.close()
        d.stop()

def cap_race():
    d=Driver('pr651-root-cap',39552,cap=2)
    c=WS('root-cap',d.port);initialize(c)
    try:
        a=listed(c)['selected_session_id'];wait_ready(c,[a]);d.submit('/new');d.wait('2 ready')
        for i in range(16):
            d.submit('/close')
            # Immediately submit next command; only mandatory paste-burst separation.
            d.submit('/new')
            d.wait('2 ready',15)
            data=listed(c)
            assert len([r for r in data['sessions'] if r['status'] not in ['closed','failed']])==2,data
            prompt(c,data['selected_session_id'],f'capacity iteration {i}');wait_ready(c,[data['selected_session_id']])
        d.capture('close-new-at-cap','capacity iteration 15')
        result('close at cap then new repeatedly',status='pass',iterations=16)
        snapshot_processes('before-quit-cap');d.submit('/quit');time.sleep(1);snapshot_processes('after-quit-cap')
    finally:
        c.close();d.stop()

if __name__=='__main__':
    for fn in [run,cap_race]:
        try:fn()
        except Exception as e:
            traceback.print_exc();result(fn.__name__,status='test-error',error=str(e))
