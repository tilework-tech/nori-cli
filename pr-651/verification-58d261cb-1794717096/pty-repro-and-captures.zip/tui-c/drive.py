import json, pathlib, shlex, subprocess, time, sys, traceback
ROOT=pathlib.Path('/home/sprite/org/workspace/cli/.local/pr651-verification/tui-c')
BIN=pathlib.Path('/home/sprite/org/workspace/cli/.local/pr651-target/debug')
SCRIPTS=pathlib.Path('/home/sprite/org/workspace/.codex/skills/tui-puppeteering-with-tmux')
RESULTS=ROOT/'results.json'

def tool(name,*args,check=True):
    p=subprocess.run([str(SCRIPTS/name),*map(str,args)],text=True,capture_output=True)
    if check and p.returncode: raise RuntimeError(f'{name} failed: {p.stderr}')
    return p.stdout

class Driver:
    def __init__(self,name,extra='',env=None,cloud=False):
        self.name='pr651-c-'+name
        self.path=ROOT/name
        self.path.mkdir(parents=True,exist_ok=True)
        self.events=[]
        cwd=str(self.path)
        (self.path/'config.toml').write_text(f'agent = "mock-model"\n[features]\nmulti_session = true\n[tui]\nmax_sessions = 4\n{extra}\n[projects.{json.dumps(cwd)}]\ntrust_level = "trusted"\n')
        subprocess.run(['git','init','-q',cwd],check=True)
        vals={'NORI_HOME':cwd,'NORI_NO_ANALYTICS':'1','NORI_MOCK_INSTRUCTION_FILES':'1','MOCK_ACP_AGENT_BIN':str(BIN/'mock_acp_agent'),'MOCK_AGENT_RESPONSE_MOCK_MODEL':'alpha agent answer','MOCK_AGENT_RESPONSE_MOCK_MODEL_ALT':'beta agent answer','MOCK_AGENT_PERMISSION_DELAY_MS':'1500','TERM':'xterm-256color'}
        if env: vals.update(env)
        if cloud:
            wrapper=self.path/'handroll-mock.sh'
            wrapper.write_text('#!/bin/sh\nexec '+shlex.quote(str(BIN/'mock_acp_agent'))+'\n')
            wrapper.chmod(0o755)
            vals.update(NORI_HANDROLL_BIN=str(wrapper),MOCK_AGENT_SUPPORT_SESSION_LIST='1',MOCK_AGENT_SUPPORT_SESSION_RESUME='1',MOCK_AGENT_SUPPORT_SESSION_CLOSE='1')
        cmd=['env',*[f'{k}={v}' for k,v in vals.items()],str(BIN/'nori')]
        if cloud: cmd+=['cloud']
        cmd+=['--agent','mock-model','--skip-trust-directory']
        launch=self.path/'launch.sh'
        launch.write_text('#!/bin/sh\ncd '+shlex.quote(cwd)+'\n'+shlex.join(cmd)+'\nprintf "\\nTEST_PROCESS_EXIT=%s\\n" "$?"\nsleep 30\n')
        launch.chmod(0o755)
        tool('tui-start',self.name,str(launch))
        self.wait('Start a new session' if cloud else 'Mock Default Model',timeout=30)
        if cloud: self.key('Enter');self.wait('Mock Default Model',timeout=25)
    def log(self,msg):
        self.events.append({'time':time.time(),'action':msg})
        (self.path/'actions.json').write_text(json.dumps(self.events,indent=2))
    def screen(self): return tool('tui-capture',self.name)
    def snap(self,name):
        text=self.screen()
        (self.path/(name+'.txt')).write_text(text)
        (self.path/(name+'.ansi')).write_text(tool('tui-capture',self.name,'-e'))
        return text
    def wait(self,text=None,pred=None,timeout=15):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            screen=self.screen()
            if (text is not None and text in screen) or (pred and pred(screen)): return screen
            time.sleep(.1)
        self.snap('FAIL')
        raise AssertionError(f'Waiting for {text or pred}:\n{screen}')
    def key(self,*keys):
        for key in keys:
            self.log('KEY '+key); tool('tui-send',self.name,'--keys',key);time.sleep(.2)
    def submit(self,text):
        self.log('INPUT '+text);tool('tui-send',self.name,text);time.sleep(.55);self.key('Enter')
    def ask(self,text,answer='alpha agent answer'):
        self.submit(text);self.wait(answer);time.sleep(.5)
    def new(self,count=None):
        self.submit('/new');self.wait(count or 'Mock Default Model');time.sleep(.7)
    def open(self): self.key('M-s');self.wait('Sessions ')
    def dismiss(self):
        self.key('Escape');self.wait(pred=lambda s:'tab: waiting only' not in s and 'tab: all sessions' not in s);time.sleep(.3)
    def stop(self):tool('tui-stop',self.name,check=False)

def record(case,status,detail):
    rows=json.loads(RESULTS.read_text()) if RESULTS.exists() else []
    rows.append({'case':case,'status':status,'detail':detail})
    RESULTS.write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)

def waiting():
    d=Driver('waiting')
    try:
        d.ask('first ready marker');d.new('2 ready')
        d.submit('mock:request-permission:echo waiting-close-proof')
        d.wait('Would you like to allow');d.key('M-,');d.wait('1 waiting on you');d.open();d.key('Down')
        d.key('C-d');s=d.wait('ctrl+d again to close');assert 'waiting on you' in s;d.snap('01-waiting-first-close')
        d.key('C-d');d.wait(pred=lambda s:any('waiting-close-proof' in line and 'closed' in line for line in s.splitlines()));d.snap('02-waiting-closed')
        d.key('C-d');d.wait('Sessions 1');s=d.snap('03-closed-row-removed');assert 'waiting-close-proof' not in s
        d.key('C-d');d.dismiss();d.wait('Use /quit to leave Nori.');d.snap('04-last-session-guidance')
        d.open();d.key('Tab');d.wait('No sessions waiting on you');d.snap('05-empty-waiting-filter');d.dismiss()
        d.submit('/quit');d.wait('TEST_PROCESS_EXIT=0',timeout=20);d.snap('06-quit')
        record('waiting double Ctrl+D, closed remove, last session, empty waiting filter','PASS','Six .txt/.ansi captures under waiting/')
    finally:d.stop()

def agent_working():
    d=Driver('agent-working')
    try:
        d.submit('alpha stream marker mock:stream-until-cancel');d.wait('esc to interrupt');d.submit('/agent')
        d.wait(pred=lambda s:'Select agent' in s or 'mock-model-alt' in s);d.snap('01-agent-picker-while-working')
        d.key('Down');d.key('Enter');d.wait('Start a new session',timeout=25);d.key('Enter');d.wait('Started new conversation with agent: Mock ACP Alt',timeout=25)
        d.ask('beta prompt while alpha working','beta agent answer');s=d.snap('02-new-agent-answers');assert '1 working' in s
        d.key('M-,');d.wait('alpha stream marker');s=d.snap('03-original-still-working');assert 'esc to interrupt' in s
        d.key('Escape');time.sleep(.5);d.submit('/quit');d.wait('TEST_PROCESS_EXIT=0',timeout=20)
        record('/agent while working','PASS','Picker opens; alternate agent answers; alpha remains streaming')
    finally:d.stop()

def resume_working():
    d=Driver('resume-working')
    try:
        d.ask('resume source marker');d.new('2 ready');d.submit('busy session marker mock:stream-until-cancel');d.wait('esc to interrupt');d.submit('/resume')
        d.wait(pred=lambda s:'Resume' in s or 'Start a new session' in s,timeout=25);d.snap('01-resume-picker-while-working')
        # The first transcript is the most recent active stream; slash activates search.
        d.key('/')
        tool('tui-send',d.name,'resume source marker');time.sleep(.7);d.snap('02-filtered-resume-picker')
        d.key('Enter');d.wait('resume source marker',timeout=25);time.sleep(1);d.snap('03-resumed-source')
        d.ask('resumed source accepts next prompt');s=d.snap('04-resumed-answers');assert '1 working' in s
        d.key('M-,');d.wait('busy session marker');s=d.snap('05-original-still-working');assert 'esc to interrupt' in s
        d.key('Escape');time.sleep(.5);d.submit('/quit');d.wait('TEST_PROCESS_EXIT=0',timeout=20)
        record('/resume while working','PASS','Resume source selected; resumed session answers; original remains working')
    finally:d.stop()

def cloud():
    d=Driver('cloud-close',cloud=True,env={'MOCK_AGENT_RESPONSE':'alpha agent answer'})
    try:
        d.ask('first cloud marker');d.new('2 ready');d.ask('second cloud marker');d.submit('/close');d.wait('first cloud marker');d.open();d.wait('Sessions 2');time.sleep(.8)
        s=d.snap('01-cloud-close-list');assert any('second cloud marker' in line and 'closed' in line for line in s.splitlines());assert 'starting' not in s and 'New session' not in s
        d.dismiss();d.submit('/quit');d.wait('TEST_PROCESS_EXIT=0',timeout=20)
        record('cloud /close no stale starting','PASS','Remaining session visible, released row closed, no starting/New session row')
    finally:d.stop()

def loop():
    d=Driver('loop',extra='loop_count = 3',env={'MOCK_AGENT_DELAY_MS':'1200'})
    try:
        d.ask('home marker');d.wait('Loop iteration 3 of 3',timeout=30);time.sleep(3);d.new('2 ready')
        d.submit('background loop marker');time.sleep(.3);d.key('M-,');d.wait('home marker')
        deadline=time.monotonic()+35
        while time.monotonic()<deadline:
            s=d.screen();assert 'background loop marker' not in s
            if '2 ready' in s:break
            time.sleep(.25)
        else:raise AssertionError('Background loop never finished')
        d.snap('01-home-unaffected');d.open();s=d.snap('02-two-rows-after-loop');assert s.count('background loop marker')==1
        d.dismiss();d.key('M-.');d.wait('Loop iteration 3 of 3');d.wait('background loop marker');d.snap('03-background-loop-completed')
        d.submit('/quit');d.wait('TEST_PROCESS_EXIT=0',timeout=20)
        record('loop config isolation','PASS','Three background iterations stay in own row; home screen remains unchanged')
    finally:d.stop()

if __name__=='__main__':
    for name in sys.argv[1:] or ['waiting','agent_working','resume_working','cloud','loop']:
        try:globals()[name]()
        except Exception as e:
            record(name,'FAIL',str(e));traceback.print_exc()
