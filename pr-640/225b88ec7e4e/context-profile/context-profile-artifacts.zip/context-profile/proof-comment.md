## Context latency + compact layout proof — 225b88ec

The middle section now uses one additive `Current` row, the checkpoint table and one carry note. The tokenizer is initialized once and instruction discovery runs off the UI event loop; every invocation still reads fresh files.

| Measured workload | Before | After |
|---|---:|---:|
| Real CLI Enter → visible frame, 8 real instruction files, median of 3 | 6,588.6 ms | 299.9 ms |
| Three-file instruction inventory, median of 5 warm repeats | 2,306.6 ms | 21.3 ms |

Same session and unoptimized debug build configuration; real CLI driven through an isolated 110×70 terminal, controlled local ACP fixture, real inherited instruction files, recording and tracing enabled. These numbers exclude real provider/network latency. First tokenizer initialization in a fresh profiling process still takes about 787 ms; startup can initialize it before `/context`.

The underlying live timeline query measured 0.65 / 7.24 / 76.86 ms at 100 / 1,000 / 10,000 turns. At 10,000 turns JSONL loading takes 3,091.6 ms and checkpoint reconstruction 184.9 ms, but those are resume workloads—not work repeated by `/context`. Seven samples per workload retain individual timings and correctness checks. Increasing message size 16× at 1,000 turns leaves the live query near 7 ms.

Validated: 383 Harness tests; 1,521 UI/components/mock tests; 145 PTY tests. Includes `/context` during an active prompt and two real instruction-file edits returning fresh counts within the one-second warm budget. Seven snapshots updated. Formatting, scoped Clippy, and independent reviews passed. One pre-existing test-only dead-code warning remains.

[Interactive report](https://ta-01m4hwcms5ng4ptzqnvm58s5gs-8080-9l7l3ogxd0w23bjqet5wvoz8n.preview.norisessions.com/port/8765/context-profile/?v=1791672503) · [All logs, traces, captures and driver](https://github.com/tilework-tech/nori-cli/blob/510ba681e6001e16dedd589980adb99dbd6fb97f/pr-640/225b88ec7e4e/context-profile/context-profile-artifacts.zip?raw=true) · [Raw measurements](https://github.com/tilework-tech/nori-cli/blob/510ba681e6001e16dedd589980adb99dbd6fb97f/pr-640/225b88ec7e4e/context-profile/data.json?raw=true) · [Methodology and reproduction](https://github.com/tilework-tech/nori-cli/blob/510ba681e6001e16dedd589980adb99dbd6fb97f/pr-640/225b88ec7e4e/context-profile/README.txt?raw=true) · [Terminal text](https://github.com/tilework-tech/nori-cli/blob/510ba681e6001e16dedd589980adb99dbd6fb97f/pr-640/225b88ec7e4e/context-profile/screen.txt?raw=true)

Remaining measured cost: around 100 ms for wide history/recording renders, plus fresh file encoding. No timeline algorithm rewrite was needed.

![Actual running CLI; deterministic ACP usage fixture with real instruction discovery](https://github.com/tilework-tech/nori-cli/blob/510ba681e6001e16dedd589980adb99dbd6fb97f/pr-640/225b88ec7e4e/context-profile/screen.png?raw=true)
