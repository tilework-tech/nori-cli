import subprocess,time,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
phase=sys.argv[1];out=root/phase;session='context-profile-'+phase
scripts=Path('/home/sprite/org/workspace/.goose/skills/tui-puppeteering-with-tmux')
log=(out/'driver.log').open('w')
def tool(name,*args,check=True):
 result=subprocess.run([str(scripts/name),session,*args],capture_output=True,text=True)
 log.write(json.dumps({'tool':name,'args':args,'stdout':result.stdout,'stderr':result.stderr,'status':result.returncode})+'\n');log.flush()
 if check and result.returncode: raise RuntimeError(result.stdout+result.stderr)
 return result.stdout
samples=[]
try:
 tool('tui-start',str(out/'run.sh'))
 subprocess.run([str(scripts/'tmux-isolated'),'resize-window','-t',session,'-x','110','-y','70'],check=True)
 tool('tui-assert','›','30')
 for marker,used in [('ALPHA',10000),('BETA',30000),('GAMMA',50000)]:
  tool('tui-send',marker);tool('tui-assert','-E','› '+marker,'10');tool('tui-send','--keys','Enter')
  tool('tui-assert','RESPONSE_'+marker,'20')
  tool('tui-send','/context');tool('tui-assert','/ context','10')
  started=time.perf_counter();tool('tui-send','--keys','Enter')
  expected=f'{used:,} / 100,000 tokens'
  while True:
   screen=tool('tui-capture')
   if expected in screen: break
   if time.perf_counter()-started>25: raise RuntimeError('context frame timeout: '+screen)
   time.sleep(.025)
  elapsed=(time.perf_counter()-started)*1000
  (out/('screen-'+marker+'.txt')).write_text(screen)
  sample={'prompt':marker,'used':used,'elapsed_ms':elapsed,'metric':'enter_to_visible_frame','profile':'debug','fixture':'recognized Claude instruction discovery + local mock ACP'}
  samples.append(sample);print(json.dumps(sample),flush=True)
 (out/'e2e.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in samples))
 tool('tui-assert','Current ·','5')
 print('READY_FOR_CAPTURE '+session,flush=True)
except BaseException:
 tool('tui-stop',check=False)
 raise
finally:
 log.close()
