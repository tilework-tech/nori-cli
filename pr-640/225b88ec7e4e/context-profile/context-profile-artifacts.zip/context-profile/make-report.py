from pathlib import Path
import json,statistics,shutil
r=Path(__file__).resolve().parent
out=Path('/home/sprite/org/workspace/.worktrees/nori-context-preview/context-profile')
out.mkdir(exist_ok=True)
def read(p):return [json.loads(x) for x in p.read_text().splitlines()]
data={'harness':read(r/'integration/harness.jsonl'),'e2e':{},'inventory':{},'stages':{}}
for phase in ['before','after']:
 data['e2e'][phase]=read(r/phase/'e2e.jsonl')
 data['inventory'][phase]=read(r/phase/'instruction-inventory.jsonl')
 data['stages'][phase]=read(r/phase/'stages.jsonl')
 shutil.copy2(r/phase/'capture/screen.png',out/f'{phase}.png')
(out/'data.json').write_text(json.dumps(data,indent=2)+'\n')
html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>/context profiling · PR 640</title><style>
:root{color-scheme:dark;font:16px/1.55 system-ui;background:#111513;color:#e4ece6}body{max-width:1100px;margin:40px auto;padding:0 24px}h1{font-size:32px}h2{font-size:21px;margin-top:32px}p{max-width:880px;color:#bfc9c2}a{color:#67dd92}button,select{font:inherit;background:#202a23;color:inherit;padding:8px 12px;border:1px solid #526556;border-radius:5px}button[aria-pressed=true]{border-color:#69df93;color:#69df93}table{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums}th,td{text-align:left;padding:10px;border-bottom:1px solid #344239}th{color:#a4b5a9}code{color:#8ce7aa}.bar{background:#3bb56b;height:22px;min-width:1px;border-radius:3px}.row{display:grid;grid-template-columns:100px 1fr 100px;align-items:center;gap:16px;margin:12px 0}.metric{font-size:36px;font-weight:700;color:#76e69d}.card{border:1px solid #344239;padding:20px;margin:20px 0;border-radius:8px}img{max-width:100%;background:#161616}summary{cursor:pointer}small{color:#a4b5a9}.layout{display:flex;gap:24px;flex-wrap:wrap}.layout>div{flex:1;min-width:250px}#samples{font-size:13px;white-space:pre-wrap;max-height:300px;overflow:auto}input{accent-color:#56d883}</style>
<h1><code>/context</code> profiling</h1><p>PR #640 · Actual CLI, real instruction files, controlled local ACP fixture. All timings are from the same unoptimized debug build configuration on this session. No provider API calls were needed.</p>
<p><a href="https://github.com/tilework-tech/nori-cli/pull/640">Review PR</a> · <a href="data.json">Raw measurements</a> · <a href="context-profile-artifacts.zip">Logs, traces, captures and driver</a></p>
<div class="card"><div class="metric" id="headline"></div><p>Median Enter → visible context frame, three successive turns. Eight instruction files totaling about 105 KB. Same 110×70 terminal, recording and debug tracing enabled before and after. Includes driver polling overhead.</p><div id="live"></div></div>
<h2>What changed</h2><p>Each instruction file rebuilt the tokenizer’s vocabulary. The CLI now initializes one reusable tokenizer and collects files on a blocking worker, keeping input responsive. Files and counts are read afresh each time. The middle section is one additive Current row, the checkpoint table and one short carry note.</p>
<h2>Separate the workloads</h2><label>Workload <select id="workload"><option value="live_snapshot">Live /context timeline query</option><option value="timeline_reduce">Checkpoint reconstruction</option><option value="jsonl_load">JSONL transcript load</option></select></label> <label><input id="large" type="checkbox"> Include 16 KB messages</label><table><thead><tr><th>Turns</th><th>Message size</th><th>Transcript size</th><th>Median</th><th>Maximum</th></tr></thead><tbody id="table"></tbody></table>
<p>Seven samples per case. Fixtures contain prompt lifecycle events, user/agent chunks and ACP usage metadata. Fixture creation is excluded; correctness checks run outside timers. JSONL load and reconstruction happen on resume. Each live query clones the existing timeline; message payload size does not materially change its cost.</p>
<h2>Instruction inventory</h2><table><thead><tr><th>Three files / 17.1 KB</th><th>Before</th><th>After</th></tr></thead><tbody id="inventory"></tbody></table><p>“Cold” means first invocation in a fresh test process, not an OS cache flush. Repeats share the tokenizer. An additional edit verifies the next reading changes. Live CLI startup can initialize the tokenizer before the first command.</p>
<h2>Live stage timings</h2><table><thead><tr><th>Stage · median</th><th>Before</th><th>After</th></tr></thead><tbody id="stages"></tbody></table><p>Inventory contains tokenization; queue insertion contains two unbounded-width renders because recording is enabled. These rows overlap and must not be summed. The visible-width render is about 2 ms. The remaining roughly 100 ms of wide rendering is separate from tokenizer work and has not been changed.</p>
<h2>Running terminal capture</h2><button id="before" aria-pressed="false">Before performance fix</button> <button id="after" aria-pressed="true">After performance fix</button><p>Both captures already use the compact layout; only the performance implementation differs. No screenshot edits. The latest full snapshot is below an earlier turn in terminal scrollback.</p><img id="capture" src="after.png" alt="Real Nori terminal showing compact context and checkpoint table">
<details><summary>Individual live measurements</summary><pre id="samples"></pre></details>
<script>
const data=DATA;const med=a=>[...a].sort((a,b)=>a-b)[Math.floor(a.length/2)];const fmt=n=>n<1?n.toFixed(3)+' ms':n.toFixed(1)+' ms';
const b=med(data.e2e.before.map(x=>x.elapsed_ms)),a=med(data.e2e.after.map(x=>x.elapsed_ms));
headline.textContent=(b/1000).toFixed(2)+' s → '+(a/1000).toFixed(2)+' s · '+(b/a).toFixed(1)+'× faster';
for(const [name,n] of [['Before',b],['After',a]])live.insertAdjacentHTML('beforeend',`<div class="row"><span>${name}</span><div class="bar" style="width:${n/b*100}%"></div><span>${fmt(n)}</span></div>`);
function render(){table.innerHTML=data.harness.filter(x=>x.stage===workload.value&&(large.checked||x.message_bytes===1024)).map(x=>`<tr><td>${x.turns.toLocaleString()}</td><td>${x.message_bytes/1024} KB</td><td>${(x.fixture_bytes/1e6).toFixed(2)} MB</td><td>${fmt(x.median_ms)}</td><td>${fmt(x.max_ms)}</td></tr>`).join('')}workload.onchange=large.onchange=render;render();
for(const [label,fn] of [['First invocation',x=>x[0].elapsed_us/1000],['Warm median · five repeats',x=>med(x.slice(1).map(x=>x.elapsed_us/1000))]])inventory.insertAdjacentHTML('beforeend',`<tr><td>${label}</td><td>${fmt(fn(data.inventory.before))}</td><td>${fmt(fn(data.inventory.after))}</td></tr>`);
for(const [label,key,field] of [['Timeline clone','harness_snapshot','clone_us'],['Instruction inventory','instruction_inventory','elapsed_us'],['History queue insertion','context_history_queued','elapsed_us']]){const vals=['before','after'].map(p=>med(data.stages[p].filter(x=>x.stage===key).map(x=>x[field]/1000)));stages.insertAdjacentHTML('beforeend',`<tr><td>${label}</td><td>${fmt(vals[0])}</td><td>${fmt(vals[1])}</td></tr>`)}
for(const name of ['before','after'])document.getElementById(name).onclick=()=>{capture.src=name+'.png';for(const x of ['before','after'])document.getElementById(x).setAttribute('aria-pressed',String(x===name))};samples.textContent=JSON.stringify(data.e2e,null,2);
</script></html>'''.replace('DATA',json.dumps(data))
(out/'index.html').write_text(html)
print(out)
