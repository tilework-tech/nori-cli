## Summary
🤖 Generated with [Nori](https://noriagentic.com/)

`/context` displays current context-window occupancy and checkpoints at each Nori prompt’s start and end. The grid alternates square patterns across observed growth segments and highlights the latest turn in green. A compact `Current` row combines baseline and turn sizes, followed by the checkpoint table and one carry note.

The Harness derives checkpoints from ordered ACP usage updates and prompt lifecycle events. Missing/carried readings remain explicit, late updates never rewrite completed turns, and compaction or window changes reset attribution. History survives resume and fork through the transcript’s original observation metadata. The local command also works during an active prompt without submitting a new prompt.

Repeated `/context` commands previously rebuilt the BPE tokenizer for every instruction file on the UI thread. Tokenizer initialization is now shared, and a blocking worker collects the complete inventory while the live timeline query runs. Files are read afresh; session/conversation guards reject stale results. With eight real instruction files, the driven debug CLI improved from a 6.59s median to 0.30s (~22×). The three-file inventory profile improved from 2.31s to 21ms warm. The timeline algorithm itself was not the cause.

Profiling covers JSONL loading, checkpoint reconstruction and live snapshot queries independently through 10,000 turns, with content-free stage tracing. Live queries clone existing state; they do not reload transcripts.

[Profiling and visual proof](https://github.com/tilework-tech/nori-cli/pull/640#issuecomment-6103088675) includes the live capture, raw timings, consolidated logs and an interactive report.

## Validation
- [x] Harness boundaries, metadata, missing/late observations, compaction, queueing, failure, interrupted resume, fork and repeated resume.
- [x] Narrow/wide/unknown output snapshots, green current-segment rendering and responsive async dispatch.
- [x] Real CLI PTY coverage includes active-prompt `/context` and fresh instruction counts after two edits within a one-second warm budget.
- [x] Isolated profiles: three real instruction files and 0/100/1,000/10,000-turn transcript fixtures, seven samples per Harness workload.
- [x] Driven real CLI before/after, real inherited instructions and controlled local ACP fixture, with logs, traces, terminal captures and an interactive report.
- [x] Final suites: Harness 383; UI/components/mock 1,521; PTY 145 passing tests. Build, formatting and scoped Clippy passed.
- [x] Final-commit PR CI: Linux checks and cargo-deny passed.

Local instruction sizes remain estimates, not proof of retained context or category ownership. Performance numbers use unoptimized debug builds with recording enabled; provider network/model latency is excluded. First tokenizer initialization still has a one-time cost; fresh file reads/encoding and wide transcript rendering remain measurable.

The preparation-cleanup tests distinguish stopped zombie descendants from running processes while retaining strict direct-child reaping checks.

Share Nori with your team: https://www.npmjs.com/package/nori-skillsets
