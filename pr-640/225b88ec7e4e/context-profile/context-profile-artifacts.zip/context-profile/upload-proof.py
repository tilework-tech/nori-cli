import os, subprocess, tempfile, json
from pathlib import Path
repo='tilework-tech/nori-cli'
def git(*args,**kw):return subprocess.check_output(['git',*args],text=True,**kw).strip()
head=git('rev-parse','HEAD')
git('fetch','-q','origin','nori/pr-proofs')
base=git('rev-parse','refs/remotes/origin/nori/pr-proofs')
root=Path('.local/context-profile')
report=Path('/home/sprite/org/workspace/.worktrees/nori-context-preview/context-profile')
files={'screen.png':root/'after/capture/screen.png','screen.txt':root/'after/capture/screen.txt','data.json':report/'data.json','README.txt':root/'README.txt','context-profile-artifacts.zip':report/'context-profile-artifacts.zip'}
with tempfile.TemporaryDirectory(prefix='context-profile-proof-') as tmp:
 env=dict(os.environ,GIT_INDEX_FILE=str(Path(tmp)/'index'))
 git('read-tree',base,env=env)
 paths={}
 for name,source in files.items():
  dest=f'pr-640/{head[:12]}/context-profile/{name}'
  blob=git('hash-object','-w',str(source));git('update-index','--add','--cacheinfo',f'100644,{blob},{dest}',env=env)
  paths[name]=dest
 tree=git('write-tree',env=env)
 commit=git('commit-tree',tree,'-p',base,'-m',f'proof: context latency and compact layout at {head[:12]}')
subprocess.run(['git','push','origin',f'{commit}:refs/heads/nori/pr-proofs'],check=True)
urls={name:f'https://github.com/{repo}/blob/{commit}/{dest}?raw=true' for name,dest in paths.items()}
(root/'proof-urls.json').write_text(json.dumps(urls,indent=2)+'\n')
print(json.dumps({'head':head,'proof_commit':commit,'urls':urls},indent=2))
