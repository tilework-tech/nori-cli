#!/bin/bash
unset NO_COLOR NORI_MOCK_INSTRUCTION_FILES
export COLORTERM=truecolor TERM=xterm-256color
export NORI_HOME=/home/sprite/org/workspace/cli/.local/context-profile/before/nori-home
export RUST_LOG=nori_context_profile=debug,nori_tui=warn,nori_harness=warn,nori_acp_host=warn
export CODEX_TUI_RECORD_SESSION=1
export CODEX_TUI_SESSION_LOG_PATH=/home/sprite/org/workspace/cli/.local/context-profile/before/session-events.jsonl
export MOCK_AGENT_MULTI_TURN=1
export MOCK_AGENT_CONTEXT_SEQUENCE='[[{"used":10000,"size":100000}],[{"used":30000,"size":100000}],[{"used":50000,"size":100000}]]'
cd /home/sprite/org/workspace/cli/.local/context-profile/fixtures/project
exec /home/sprite/org/workspace/cli/nori-rs/target/debug/nori --agent claude-context-fixture --skip-trust-directory
